#!/usr/bin/env python3
###############################################################

def getMasses():
    fin = open("acmass2.dat","r")
    lines = fin.readlines()
    masses = []
    for lns in lines:
        wds = lns.split(' ')
        masses.append(int(wds[1].strip()))
     
    return masses 

###############################################################

def getPartMassList(listP, start, length):
    m = 0
    for i in range(0, length):
       m = m + listP[ (start + i ) % len(listP) ]
    
    return m

###############################################################

def expandList( pepList, masses ):
    for k in pepList:
      for m in masses:
         k.append( m )
        
    
###############################################################


def getSpectrumByMass(massList):
    massList.sort()
    ll=len(massList)
    vals = [0, getPartMassList(massList,0,ll)]
    for length in range(1,ll):
     for start in range(0,ll):
       ss = getPartMassList(massList, start, length)
       vals.append(ss)

    vals.sort()
    return vals 


###############################################################

def outputMList(mlist):
   for m in mlist:
      print(m,end='')
      print('-', end=' ')
   print()      

###############################################################

def CykloSeq(spectrum):
   l1 = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[] ]
   masses = getMasses()
   expandList(l1, masses)
   
#   l1.append(masses) 
#   print(l1)
   while len( l1 ) != 0 :
      expandList(l1, masses)
      for mlist in l1:
         if getSpectrumByMass(mlist) == spectrum:
            output(mlist)
            del  l1[ l1.index(mlist) ]
         else:
            del  l1[ l1.index(mlist) ]

###############################################################

def readSpectrum(fileIn):
   fin = open(fileIn,"r")
   spec = []
   lines = fin.readlines()
   for lns in lines:
      wds = lns.split(' ')
      for k in wds:  
        spec.append(int(k.strip())) 
   return spec
   
   
   
##############################################################   
spectrum = readSpectrum("input.dat")
#print(spectrum) 
masses = getMasses()
massList = [ 1, 10, 100 ]
print(getSpectrumByMass(massList))
#CykloSeq(spectrum)   
   

